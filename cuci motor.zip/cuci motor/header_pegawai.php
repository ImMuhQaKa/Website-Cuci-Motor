<!DOCTYPE html>
<html>
<head>
    <title>Sistem Keuangan Cuci Motor Pegawai</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "navbar_pegawai.php"; ?>
