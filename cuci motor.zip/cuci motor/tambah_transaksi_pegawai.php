<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';
$error = '';
$pegawai = $_SESSION['username']; // username pegawai yang login

// proses simpan data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal    = trim($_POST['tanggal'] ?? '');
    $jenis      = trim($_POST['jenis'] ?? '');
    $keterangan = trim($_POST['keterangan'] ?? '');
    $jumlah     = (float) ($_POST['jumlah'] ?? 0);
    $metode     = trim($_POST['metode'] ?? '');

    if ($tanggal === '' || $jenis === '' || $jumlah <= 0 || $metode === '') {
        $error = 'Lengkapi semua field dengan benar.';
    } else {
        $sql = "INSERT INTO transaksi 
                (tanggal, jenis, keterangan, jumlah, metode_pembayaran, pegawai) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $sql);
        if ($stmt) {
            // ✔ diperbaiki: harus "sssdss" karena ada 6 parameter
            mysqli_stmt_bind_param($stmt, "sssdss", $tanggal, $jenis, $keterangan, $jumlah, $metode, $pegawai);
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_close($stmt);
                header("Location: transaksi_pegawai.php"); // kembali ke dashboard pegawai
                exit;
            } else {
                $error = "Insert gagal: " . mysqli_error($koneksi);
            }
        } else {
            $error = "Prepare statement gagal: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Transaksi Pegawai</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<style>
/* Styling form agar lebih rapi */
.form-container {
    max-width: 600px;
    margin: 40px auto;
    background: #ffffff;
    padding: 25px 30px;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}
.form-container h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #1e5bb8;
}
.form-container table { width: 100%; }
.form-container td { padding: 10px 5px; }
.form-container input, .form-container select {
    width: 100%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 6px;
}
.form-container button {
    background: #1e5bb8;
    color: white;
    padding: 10px 18px;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}
.form-container button:hover { background: #174a94; }
.form-container a {
    margin-left: 10px;
    text-decoration: none;
    color: #333;
}
.error-msg {
    color: red;
    margin-bottom: 10px;
    text-align: center;
}
</style>

<div class="form-container">
    <h2>➕ Tambah Transaksi Pegawai</h2>

    <?php if ($error): ?>
        <div class="error-msg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <table>
            <tr>
                <td>Tanggal</td>
                <td><input type="date" name="tanggal" required 
                    value="<?= htmlspecialchars($_POST['tanggal'] ?? '') ?>"></td>
            </tr>
            <tr>
                <td>Jenis</td>
                <td>
                    <select name="jenis" required>
                        <option value="">-- Pilih Jenis --</option>
                        <option value="pemasukan" <?= (($_POST['jenis'] ?? '') === 'pemasukan') ? 'selected' : '' ?>>Pemasukan</option>
                        <option value="pengeluaran" <?= (($_POST['jenis'] ?? '') === 'pengeluaran') ? 'selected' : '' ?>>Pengeluaran</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Keterangan</td>
                <td><input type="text" name="keterangan" required 
                    value="<?= htmlspecialchars($_POST['keterangan'] ?? '') ?>"></td>
            </tr>
            <tr>
                <td>Jumlah (Rp)</td>
                <td><input type="number" name="jumlah" required 
                    value="<?= htmlspecialchars($_POST['jumlah'] ?? '') ?>" step="0.01" min="0"></td>
            </tr>
            <tr>
                <td>Metode Pembayaran</td>
                <td>
                    <select name="metode" required>
                        <option value="">-- Pilih Metode --</option>
                        <option value="Tunai" <?= (($_POST['metode'] ?? '') === 'Tunai') ? 'selected' : '' ?>>Tunai</option>
                        <option value="Non-Tunai" <?= (($_POST['metode'] ?? '') === 'Non-Tunai') ? 'selected' : '' ?>>Non-Tunai</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="text-align:center;">
                    <button type="submit">💾 Simpan</button>
                    <a href="transaksi_pegawai.php">❌ Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

<?php include 'footer.php'; ?>
</body>
</html>
