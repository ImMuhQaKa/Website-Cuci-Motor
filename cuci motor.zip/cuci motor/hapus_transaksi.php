<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $query = "DELETE FROM transaksi WHERE id_transaksi = $id";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        if (mysqli_affected_rows($koneksi) > 0) {
            echo "<script>alert('Data berhasil dihapus'); window.location.href='transaksi.php';</script>";
        } else {
            echo "<script>alert('Data tidak ditemukan di database (id=$id)'); window.location.href='transaksi.php';</script>";
        }
    } else {
        echo "<script>alert('Gagal hapus: " . mysqli_error($koneksi) . "');</script>";
    }
} else {
    header("Location: transaksi.php");
    exit;
}
