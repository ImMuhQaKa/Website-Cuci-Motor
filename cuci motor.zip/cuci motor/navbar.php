<!-- navbar.php -->
<style>
  nav {
    background-color: #1e5ab6;
    padding: 12px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between; /* logo kiri, menu kanan */
    margin-bottom: 20px;
  }
  .nav-left {
    display: flex;
    align-items: center;
  }
  .nav-left img {
    height: 60px; /* ukuran logo */
    margin-right: 10px;
  }
  .nav-links {
    display: flex;
    align-items: center;
  }
  .nav-links a {
    color: #fff;
    margin-left: 20px;
    text-decoration: none;
    font-weight: bold;
  }
  .nav-links a:hover {
    text-decoration: underline;
  }
</style>

<nav>
  <div class="nav-left">
    <img src="bersih.png" alt="Logo">
    <span style="color:#fff; font-weight:bold;">Cuci Motor Berkah</span>
  </div>
  <div class="nav-links">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="transaksi.php">💰 Transaksi</a>
    <a href="laporan.php">📊 Laporan</a>
    <a href="logout.php">🚪 Logout</a>
  </div>
</nav>
