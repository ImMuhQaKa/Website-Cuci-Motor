<div class="footer_pegawai">
    <p>© 2025 Sistem Informasi Usaha Cuci Motor - Pegawai</p>
</div>
</body>
</html>
