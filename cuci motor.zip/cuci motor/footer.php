<div class="footer">
    <p>© 2025 Sistem Informasi Usaha Cuci Motor</p>
</div>
</body>
</html>
