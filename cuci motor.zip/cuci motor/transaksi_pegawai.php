<?php
include 'koneksi.php';
include 'header_pegawai.php';

// Ambil data transaksi
$query = "SELECT * FROM transaksi ORDER BY tanggal DESC";
$result = mysqli_query($koneksi, $query);

if (!$result) {
    die("Query Error: " . mysqli_error($koneksi));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Transaksi</title>
    <style>
        /* --- General --- */
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fff5e6, #1e5bb8); /* gradasi cream ke biru */
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            padding: 20px;
            margin: 20px auto;
            background: #fff;
            border-radius: 12px;
            max-width: 1000px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #1e5bb8;
        }

        /* --- Tabel --- */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 14px;
        }

        table th, table td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        table th {
            background: linear-gradient(135deg, #fff5e6, #dfefff);
            color: #1e5bb8;
        }

        table tr:nth-child(even) {background: #f9f9f9;}
        table tr:hover {background: #e9f7ff;}

        /* --- Tombol --- */
        .btn-edit, .btn-hapus {
            padding: 6px 12px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-edit { color: #fff; background: #2196F3; }
        .btn-edit:hover { background: #0b7dda; }

        .btn-hapus { color: #fff; background: #f44336; }
        .btn-hapus:hover { background: #da190b; }

        .add-button {
            display: inline-block;
            margin: 10px 0;
            padding: 8px 16px;
            background: #4CAF50;
            color: #fff;
            text-decoration: none;
            border-radius: 6px;
            transition: 0.3s;
        }

        .add-button:hover { background: #45a049; }

        /* --- Responsive --- */
        @media screen and (max-width: 768px) {
            table, thead, tbody, th, td, tr { display: block; }
            table tr { margin-bottom: 15px; }
            table td {
                text-align: right;
                padding-left: 50%;
                position: relative;
            }
            table td::before {
                content: attr(data-label);
                position: absolute;
                left: 10px;
                font-weight: bold;
                text-align: left;
            }
            table th { display: none; }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Data Transaksi Pegawai</h2>
    <a href="tambah_transaksi_pegawai.php" class="add-button">+ Tambah Transaksi</a>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Jenis</th>
                <th>Keterangan</th>
                <th>Jumlah (Rp)</th>
                <th>Metode Pembayaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php 
        $no = 1; 
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $id = isset($row['id_transaksi_pegawai']) ? (int)$row['id_transaksi_pegawai'] : 0;
                $tanggal = isset($row['tanggal']) ? htmlspecialchars($row['tanggal']) : '-';
                $jenis = isset($row['jenis']) ? htmlspecialchars($row['jenis']) : '-';
                $keterangan = isset($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-';
                $jumlah = isset($row['jumlah']) ? number_format($row['jumlah'], 0, ',', '.') : '0';
                $metode = isset($row['metode_pembayaran']) ? htmlspecialchars($row['metode_pembayaran']) : '-';
        ?>
            <tr>
                <td data-label="No"><?php echo $no++; ?></td>
                <td data-label="Tanggal"><?php echo $tanggal; ?></td>
                <td data-label="Jenis"><?php echo ucfirst($jenis); ?></td>
                <td data-label="Keterangan"><?php echo $keterangan; ?></td>
                <td data-label="Jumlah">Rp <?php echo $jumlah; ?></td>
                <td data-label="Metode"><?php echo $metode; ?></td>
                <td data-label="Aksi">
                    <?php if ($id > 0) { ?>
                        <a href="edit_transaksi.php?id=<?php echo $id; ?>" class="btn-edit">Edit</a>
                        <a href="hapus_transaksi.php?id=<?php echo $id; ?>" class="btn-hapus" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                    <?php } else { echo '-'; } ?>
                </td>
            </tr>
        <?php 
            } 
        } else { ?>
            <tr>
                <td colspan="7" style="text-align:center; color:red;">Data transaksi belum ada</td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

<footer class="footer">
    &copy; <?php echo date("Y"); ?> Sistem Keuangan Cuci Motor - Pegawai
</footer>
</body>
</html>
