<?php
include 'koneksi.php';

// Hitung total pemasukan, pengeluaran, dan saldo
$pemasukan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(jumlah) as total FROM transaksi WHERE jenis='pemasukan'"))['total'] ?? 0;
$pengeluaran = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(jumlah) as total FROM transaksi WHERE jenis='pengeluaran'"))['total'] ?? 0;
$saldo = $pemasukan - $pengeluaran;

// Ambil semua data transaksi untuk tabel
$query = "SELECT * FROM transaksi ORDER BY tanggal DESC";
$result = mysqli_query($koneksi, $query);
$transaksi = [];
while ($row = mysqli_fetch_assoc($result)) {
    $transaksi[] = $row;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Keuangan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            padding:0; 
            margin:0; 
            background: linear-gradient(135deg, #f5f5dc, #1e5ab6); 
            min-height: 100vh;
        }

        /* Navbar */
        nav {
            background-color: #1e5ab6;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .nav-left {
            display: flex;
            align-items: center;
        }
        .nav-left img {
            height: 60px;
            margin-right: 10px;
            border-radius: 50%; /* bulat */
        }
        .nav-left span {
            color: #fff;
            font-weight: bold;
            font-size: 20px;
        }
        .nav-links {
            display: flex;
            align-items: center;
        }
        .nav-links a {
            color: #fff;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .nav-links a:hover {
            text-decoration: underline;
        }

        .container { padding:20px; }

        canvas { 
            max-width: 600px; 
            margin:20px auto; 
            display:block; 
            background: #fff; 
            border-radius: 10px; 
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        .table-container {
            max-width: 900px;
            margin: 20px auto;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }

        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top:10px; 
            display:none; 
        }
        th, td { 
            border:1px solid #ccc; 
            padding:10px; 
            text-align:center; 
        }
        th { 
            background:#f2f2f2; 
        }
    </style>
</head>
<body>

<!-- Navbar dengan logo -->
<nav>
    <div class="nav-left">
        <img src="bersih.png" alt="Logo">
        <span>Cuci Motor Berkah</span>
    </div>
    <div class="nav-links">
        <a href="dashboard.php">🏠 Dashboard</a>
        <a href="transaksi.php">💰 Transaksi</a>
        <a href="laporan.php">📊 Laporan</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
</nav>

<div class="container">
    <h2 style="text-align:center; color:#fff;">Laporan Keuangan</h2>

    <canvas id="laporanChart"></canvas>

    <!-- Container tabel -->
    <div class="table-container">
        <h3 style="text-align:center;">Detail Transaksi</h3>
        <table id="detailTable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Jenis</th>
                    <th>Keterangan</th>
                    <th>Jumlah (Rp)</th>
                    <th>Metode</th>
                </tr>
            </thead>
            <tbody id="detailBody"></tbody>
        </table>
    </div>
</div>

<script>
const pemasukan = <?= $pemasukan ?>;
const pengeluaran = <?= $pengeluaran ?>;
const saldo = <?= $saldo ?>;
const transaksi = <?= json_encode($transaksi) ?>;

const ctx = document.getElementById('laporanChart');
const chart = new Chart(ctx, {
    type: 'pie',
    data: {
        labels: ['Pemasukan', 'Pengeluaran', 'Saldo'],
        datasets: [{
            data: [pemasukan, pengeluaran, saldo],
            backgroundColor: ['#4CAF50', '#F44336', '#2196F3']
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'bottom' }
        },
        onClick: (e, elements) => {
            if (elements.length > 0) {
                const idx = elements[0].index;
                const kategori = chart.data.labels[idx];
                showDetail(kategori);
            }
        }
    }
});

function showDetail(kategori) {
    const tbody = document.getElementById('detailBody');
    const table = document.getElementById('detailTable');
    tbody.innerHTML = '';

    let filtered = [];
    if (kategori === 'Pemasukan') {
        filtered = transaksi.filter(t => t.jenis === 'pemasukan');
    } else if (kategori === 'Pengeluaran') {
        filtered = transaksi.filter(t => t.jenis === 'pengeluaran');
    } else {
        filtered = transaksi;
    }

    if (filtered.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="color:red;">Data tidak tersedia</td></tr>`;
    } else {
        filtered.forEach((t, i) => {
            tbody.innerHTML += `
                <tr>
                    <td>${i+1}</td>
                    <td>${t.tanggal}</td>
                    <td>${t.jenis}</td>
                    <td>${t.keterangan ?? '-'}</td>
                    <td>Rp ${Number(t.jumlah).toLocaleString('id-ID')}</td>
                    <td>${t.metode_pembayaran ?? '-'}</td>
                </tr>`;
        });
    }

    table.style.display = 'table';
}
</script>

</body>
</html>
