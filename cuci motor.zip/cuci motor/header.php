<!DOCTYPE html>
<html>
<head>
    <title>Sistem Keuangan Cuci Motor</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include "navbar.php"; ?>
