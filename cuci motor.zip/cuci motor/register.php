<?php
session_start();
include 'koneksi.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $role     = mysqli_real_escape_string($koneksi, $_POST['role']);

    // hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // cek apakah username sudah ada
    $check = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username'");
    if (mysqli_num_rows($check) > 0) {
        $message = "❌ Username sudah terpakai!";
    } else {
        $query = "INSERT INTO users (username, password, role) VALUES ('$username','$hashed_password','$role')";
        if (mysqli_query($koneksi, $query)) {
            $message = "✅ Registrasi berhasil, silakan login.";
        } else {
            $message = "❌ Terjadi kesalahan: " . mysqli_error($koneksi);
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fff5e6, #1e5bb8);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        /* Logo di luar container */
        .logo {
            margin-bottom: 20px;
            text-align: center;
        }
        .logo img {
            width: 150px;   /* diperbesar */
            height: 150px;  /* diperbesar */
            border-radius: 50%;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .register-box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            width: 360px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.25);
            text-align: center;
        }
        h2 {
            color: #1e5bb8;
            margin-bottom: 15px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            outline: none;
        }
        input:focus, select:focus {
            border-color: #1e5bb8;
            box-shadow: 0 0 6px rgba(30, 91, 184, 0.3);
        }
        button {
            background: #1e5bb8;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }
        button:hover {
            background: #174a94;
        }
        .message {
            margin-top: 10px;
            color: red;
            text-align: center;
            font-weight: bold;
        }
        .login-link {
            text-align: center;
            margin-top: 12px;
        }
        .login-link a {
            color: #1e5bb8;
            text-decoration: none;
            font-weight: bold;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Logo di luar container -->
    <div class="logo">
        <img src="bersih.png" alt="Logo Aplikasi">
    </div>

    <div class="register-box">
        <h2>Register Akun</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role" required>
                <option value="">-- Pilih Role --</option>
                <option value="admin">Admin</option>
                <option value="pegawai">Pegawai</option>
            </select>
            <button type="submit">Register</button>
        </form>
        <div class="message"><?= $message ?></div>
        <div class="login-link">
            <p>Sudah punya akun? <a href="login.php">Login di sini</a></p>
        </div>
    </div>
</body>
</html>
