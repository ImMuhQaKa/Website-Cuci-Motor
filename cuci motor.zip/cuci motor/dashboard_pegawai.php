<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
include 'header_pegawai.php';
?>


<!-- Dashboard Pegawai -->
<style>
/* --- Background & Body --- */
body {
    background: linear-gradient(135deg, #fff5e6, #1e5bb8); /* gradasi cream → biru */
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

/* --- Dashboard container --- */
.dashboard-container {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 80vh;
}

/* --- Welcome Box --- */
.welcome-box {
    background: linear-gradient(180deg, #fff5e6, #f0f7ff);
    padding: 40px 30px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    text-align: center;
    max-width: 500px;
    animation: fadeIn 1s ease-out;
}

.welcome-box h2 {
    color: #1e5bb8;
    margin-bottom: 15px;
}

.welcome-box p {
    color: #333;
    margin-bottom: 25px;
    font-size: 16px;
}

/* --- Tombol menu --- */
.btn-menu {
    display: inline-block;
    margin: 10px 10px 0 0;
    padding: 12px 25px;
    border-radius: 8px;
    text-decoration: none;
    color: #fff;
    background: linear-gradient(135deg, #1e5bb8, #174a94);
    font-weight: bold;
    transition: 0.3s;
}

.btn-menu:hover {
    background: linear-gradient(135deg, #174a94, #123870);
}

/* --- Animasi --- */
@keyframes fadeIn {
    from {opacity: 0; transform: translateY(-20px);}
    to {opacity: 1; transform: translateY(0);}
}

/* --- Footer --- */
.footer {
    text-align: center;
    padding: 15px;
    background: #174a94;
    color: #fff;
    position: fixed;
    bottom: 0;
    width: 100%;
}

/* --- Responsive --- */
@media screen and (max-width: 600px) {
    .welcome-box {
        width: 90%;
        padding: 30px 20px;
    }
}
</style>

<div class="dashboard-container">
  <div class="welcome-box">
    <h2>👋 Selamat Datang, Pegawai</h2>
    <p>Gunakan menu untuk mencatat transaksi harian.</p>

  </div>
</div>

<footer class="footer">
    &copy; <?php echo date("Y"); ?> Sistem Keuangan Cuci Motor - Pegawai
</footer>
