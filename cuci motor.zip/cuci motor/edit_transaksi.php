<?php
include 'koneksi.php';

// hilangkan include header.php karena ada navbar
// include 'header.php';

if (!isset($_GET['id'])) {
    header("Location: transaksi.php");
    exit;
}

$id = intval($_GET['id']);
$query = "SELECT * FROM transaksi WHERE id_transaksi = $id LIMIT 1";
$result = mysqli_query($koneksi, $query);

if (!$result || mysqli_num_rows($result) == 0) {
    echo "<p style='color:red; text-align:center;'>Data tidak ditemukan</p>";
    include 'footer.php';
    exit;
}

$row = mysqli_fetch_assoc($result);

// Proses update data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $tanggal = $_POST['tanggal'];
    $jenis = $_POST['jenis'];
    $keterangan = $_POST['keterangan'];
    $jumlah = $_POST['jumlah'];
    $metode_pembayaran = $_POST['metode_pembayaran'];

    $update = "UPDATE transaksi 
               SET tanggal='$tanggal', jenis='$jenis', keterangan='$keterangan', jumlah='$jumlah', metode_pembayaran='$metode_pembayaran' 
               WHERE id_transaksi=$id";

    if (mysqli_query($koneksi, $update)) {
        echo "<script>alert('Data berhasil diperbarui'); window.location.href='transaksi.php';</script>";
    } else {
        echo "<script>alert('Gagal update: " . mysqli_error($koneksi) . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Transaksi</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #fdf5e6, #87CEFA);
            margin: 0;
            padding: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background: rgba(10, 29, 237, 0.79);
            color: #fff;
            text-align: center;
            padding: 18px;
            font-size: 22px;
            font-weight: bold;
            letter-spacing: 1px;
        }
        .form-container {
            max-width: 500px;
            background: #fff;
            margin: 40px auto;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 6px 15px rgba(0,0,0,0.15);
            animation: fadeIn 0.8s ease-in-out;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #444444ff;
        }
        label {
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
            color: #333;
        }
        input, select {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
            transition: 0.3s;
        }
        input:focus, select:focus {
            border-color: #2196F3;
            outline: none;
            box-shadow: 0 0 6px rgba(33,150,243,0.4);
        }
        button {
            padding: 12px;
            background: #2196F3;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            width: 100%;
            transition: 0.3s;
        }
        button:hover {
            background: #1976D2;
        }
        .btn-cancel {
            display: inline-block;
            text-align: center;
            padding: 10px 15px;
            background: #777;
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            margin-top: 10px;
            width: 100%;
            transition: 0.3s;
        }
        .btn-cancel:hover {
            background: #555;
        }
        footer {
            margin-top: auto;
            text-align: center;
            padding: 15px;
            background: rgba(255,255,255,0.7);
            font-size: 14px;
            color: #333;
        }
        @keyframes fadeIn {
            from {opacity: 0; transform: translateY(-20px);}
            to {opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>

<div class="header">✏️ Edit Transaksi</div>

<div class="form-container">
    <h2>Form Edit</h2>
    <form method="POST">
        <label>Tanggal</label>
        <input type="date" name="tanggal" value="<?php echo $row['tanggal']; ?>" required>

        <label>Jenis</label>
        <select name="jenis" required>
            <option value="pemasukan" <?php echo $row['jenis']=='pemasukan'?'selected':''; ?>>Pemasukan</option>
            <option value="pengeluaran" <?php echo $row['jenis']=='pengeluaran'?'selected':''; ?>>Pengeluaran</option>
        </select>

        <label>Keterangan</label>
        <input type="text" name="keterangan" value="<?php echo htmlspecialchars($row['keterangan']); ?>" required>

        <label>Jumlah</label>
        <input type="number" name="jumlah" value="<?php echo $row['jumlah']; ?>" required>

        <label>Metode Pembayaran</label>
        <select name="metode_pembayaran" required>
            <option value="Tunai" <?php echo $row['metode_pembayaran']=='Tunai'?'selected':''; ?>>Tunai</option>
            <option value="Non-Tunai" <?php echo $row['metode_pembayaran']=='Non-Tunai'?'selected':''; ?>>Non-Tunai</option>
        </select>

        <button type="submit">💾 Update</button>
        <a href="transaksi.php" class="btn-cancel">❌ Batal</a>
    </form>
</div>

<footer>
    &copy; <?php echo date("Y"); ?> Sistem Keuangan Cuci Motor
</footer>

</body>
</html>
