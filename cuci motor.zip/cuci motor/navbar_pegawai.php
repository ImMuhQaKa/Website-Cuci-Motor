<!-- navbar_pegawai.php -->
<style>
nav {
    background-color: #1e5bb8;
    padding: 12px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
}
.nav-left {
    display: flex;
    align-items: center;
}
.nav-left img {
    height: 40px;
    margin-right: 15px;
}
.nav-right a {
    color: #fff;
    margin: 0 15px;
    text-decoration: none;
    font-weight: bold;
}
.nav-right a:hover {
    text-decoration: underline;
}
</style>

<nav>
    <div class="nav-left">
        <img src="bersih.png" alt="Logo">
        <span style="color:#fff; font-size:18px; font-weight:bold;">Cuci Motor Berkah</span>
    </div>
    <div class="nav-right">
        <a href="dashboard_pegawai.php">🏠 Dashboard</a>
        <a href="transaksi_pegawai.php">💰 Transaksi</a>
        <a href="logout.php">🚪 Logout</a>
    </div>
</nav>
